-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2019 m. Kov 15 d. 14:08
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.2.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `raudonas_projektas`
--
CREATE DATABASE IF NOT EXISTS `raudonas_projektas` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `raudonas_projektas`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `fullname` char(254) COLLATE utf8_bin NOT NULL,
  `email` char(254) COLLATE utf8_bin NOT NULL,
  `sendmessage` mediumtext COLLATE utf8_bin NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Sukurta duomenų kopija lentelei `contact`
--

INSERT INTO `contact` (`id`, `fullname`, `email`, `sendmessage`, `date`) VALUES
(1, 'fffff', 'valdasbu@gmail.com', 'fert t hr th', '2019-03-12 15:42:14'),
(3, 'ggggg', 'Your@Email.com', 'rfer get rt y ht g btey hb gb rthbgv', '2019-03-12 15:55:23'),
(4, 'fffff dsfdfg', 'valdasbu@gmail.com', 'fsg gsrt hhrthdyhdyth d', '2019-03-14 10:03:18'),
(5, 'fas srg rtg gdff ^%$#@#', 'valdasbu@gmail.com', 'er erthtdy jtyftyhtdy h', '2019-03-14 10:05:54'),
(6, 'gh jhf hjhy', 'valdasbu@gmail.com', 'rttdh fuy gyu nfy', '2019-03-14 10:18:07'),
(7, 'fffff', 'valdasbu@gmail.com', 'g dhndh n', '2019-03-14 11:13:53'),
(8, ' hj  j fyutdydtyr', 'Your@Email.com', ' ukkjgiikfyk fkufyj', '2019-03-14 11:15:51'),
(9, 'dddd', 'Your@Email.com', '  ffc fyj yukfyu gjv', '2019-03-15 10:59:59'),
(10, 'Naujas Ä¯raÅ¡as', 'naujas@irasas.test', 'ÄŒia yra naujas Ä¯raÅ¡as, suraÅ¡ytas siekiant iÅ¡testuoti ar gerai padaryti namÅ³ darbai ', '2019-03-15 12:22:18'),
(11, 'Dar vienas', 'dar@vienas.test', 'Dar vienas Ä¯raÅ¡as ', '2019-03-15 14:04:48'),
(12, 'ggggg', 'Your@Email.com', ' epor ropa sperog iesppor isepr isgpoisgtoirposrgposigpearoi ea iesrpog ipoiproi eprio errroi epro erpiog epgoi peog ipog iepio epo', '2019-03-15 14:12:00'),
(13, 'fffff', 'Your@Email.com', ' dfgsdgsrgs', '2019-03-15 14:14:30'),
(14, 'dddd', 'Your@Email.com', '  edgd ty ty rty rty', '2019-03-15 14:16:30'),
(15, 'fffff', 'Your@Email.com', ' fgh  dhdty tdy ', '2019-03-15 15:02:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
