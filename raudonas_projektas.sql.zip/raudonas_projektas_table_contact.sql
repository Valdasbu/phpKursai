
-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `fullname` char(254) COLLATE utf8_bin NOT NULL,
  `email` char(254) COLLATE utf8_bin NOT NULL,
  `sendmessage` mediumtext COLLATE utf8_bin NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Sukurta duomenų kopija lentelei `contact`
--

INSERT INTO `contact` (`id`, `fullname`, `email`, `sendmessage`, `date`) VALUES
(1, 'fffff', 'valdasbu@gmail.com', 'fert t hr th', '2019-03-12 15:42:14'),
(3, 'ggggg', 'Your@Email.com', 'rfer get rt y ht g btey hb gb rthbgv', '2019-03-12 15:55:23'),
(4, 'fffff dsfdfg', 'valdasbu@gmail.com', 'fsg gsrt hhrthdyhdyth d', '2019-03-14 10:03:18'),
(5, 'fas srg rtg gdff ^%$#@#', 'valdasbu@gmail.com', 'er erthtdy jtyftyhtdy h', '2019-03-14 10:05:54'),
(6, 'gh jhf hjhy', 'valdasbu@gmail.com', 'rttdh fuy gyu nfy', '2019-03-14 10:18:07');
